import React from 'react';
import axios from './api'
export class Crud extends React.Component{
    
    constructor(props)
    {
        super(props)
        this.state={
            update:false,
            id:'',
            title:'',
            description:'',
            Notes:[]
        }
        
    }

    componentWillMount()
    {

        axios.get().then(res=>{
            this.setState({Notes:res.data})
            console.log(res.data)
        })

    }

    titleHandler=(event)=>
    {
        this.setState({title:event.target.value});
    }

    descHanlder=(event)=>
    {
        this.setState({description:event.target.value});
    }
    
    NOTED=(event)=>
    {
        console.log(this.props)
        event.preventDefault()
        const Notes={
            title:this.state.title,
            description:this.state.description
        }
        if(this.state.update)
        {
            axios.put(`/${this.state.id}`,Notes).then((res)=>{
                this.componentWillMount()
                this.setState({id:"",title:"",description:""})
                this.setState({update:false})
            })   
        }
        else
        {
            axios.post('/',Notes).then(res=>{
                console.log("success")
                this.componentWillMount()
            })
        }
        
    }

    Delete=(id)=>
    {
        if(window.confirm("Are You Sure You Want to delete this?"))
        {
            axios.delete(`/${id}`)
            this.componentWillMount()
        }
    }

    Update=(data)=>
    {
        this.setState({update:true})
        this.setState({id:data.id,title:data.title,description:data.description})
        console.log(this.state.title,this,this.state.description)
    }

    render() {
        return(
            <div >
          <form style={{display:'table',margin:'auto'}} onSubmit={this.NOTED} >
           <h1 style={{padding:10+'px'}}>ADD NOTES</h1>
           <div style={{padding:10+'px'}} class="form-group">
           <input type="text" value={this.state.title} onChange={this.titleHandler} placeholder="Title" />
           </div>
           <div style={{padding:10+'px'}} class="form-group">
           <textarea rows="5" value={this.state.description} onChange={this.descHanlder} placeholder="Description" cols="50" />
           </div>
           {this.state.update? <button type="submit" class="btn btn-success">Update</button>:<button type="submit" class="btn btn-success">Add Notes</button> }
           {/* {!fill && <p style={{padding:10+'px'}} class="text-danger">Please Fill all the details!!</p> } */}
           </form>
           
   
           <table class="table table-dark" style={{marginTop:100+'px'}}>
           
           <thead>
           <h1 style={{color:'black'}}>NOTES</h1>
                       <tr>
                       <th>Id</th>
                       <th>Title</th>
                       <th>Description</th>
                       <th>Delete</th>
                       <th>Update</th>
                       </tr>
           </thead>
           {
               this.state.Notes.map((data,index)=>{
                   return <tbody><tr key={(index+1)}>
                   <td>{index+1}</td>
                   <td>{data.title}</td>
                   <td>{data.description}</td>
                    <td><button class="btn btn-danger" onClick={()=>this.Delete(data.id)} >Delete</button></td>
                   <td><button class="btn btn-danger" onClick={()=>this.Update(data)} >Update</button></td>
                   </tr></tbody>
               })
           };
           </table>
           
           </div>
        )
    }
}

